import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'new-answer',
  templateUrl: './new-answer.component.html',
  styleUrls: ['./new-answer.component.css']
})
export class NewAnswerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  clickAction(){
    alert("Answer Submission Button Pressed");
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-answer',
  templateUrl: './new-answer.component.html',
  styleUrls: ['./new-answer.component.css']
})
export class NewAnswerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css']
})
export class SideBarComponent implements OnInit {
  status: Array<boolean>;

  constructor() { 
    this.status= [true,false,false,false,false];
  }

  ngOnInit(): void {
  }
  
clickEvent(index:number){
    this.status= [false,false,false,false,false];
    this.status[index] = !this.status[index];       
}

}


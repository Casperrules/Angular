import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'post-text',
  templateUrl: './post-text.component.html',
  styleUrls: ['./post-text.component.css']
})
export class PostTextComponent implements OnInit {
  @Input() content: string;
  constructor() {
    
   }

  ngOnInit(): void {
  }

}

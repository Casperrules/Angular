import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'voting',
  templateUrl: './voting.component.html',
  styleUrls: ['./voting.component.css']
})
export class VotingComponent implements OnInit {
  status:boolean;
  upvotes: number;
  constructor() { 
    this.upvotes=0;
    this.status=false;
  }

  ngOnInit(): void {
  }
  
  increaseVote(){
    this.upvotes+=1;
  }

  decreaseVote(){
    this.upvotes-=1;
  }
  toggleClass(){
    this.status=!this.status;
  }


}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-app',
  templateUrl: './main-app.component.html',
  styleUrls: ['./main-app.component.css']
})
export class MainAppComponent implements OnInit {
  status:boolean[];
  timesViewed:number;
  constructor() {
    this.timesViewed=0;
    this.status=[false,false,true]
   }

  ngOnInit(): void {
    this.timesViewed+=1;
  }



  clickEvent(index:number){
    this.status=[false,false,false];
    this.status[index]=!this.status[index];
  }

  buttonAction(){
    alert("Button Pressed");
  }


}
